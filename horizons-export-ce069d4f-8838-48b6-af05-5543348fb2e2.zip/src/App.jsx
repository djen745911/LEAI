import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import DashboardLayout from '@/pages/DashboardLayout';
import EmployeeProfilesPage from '@/pages/EmployeeProfilesPage';
import TimeAttendancePage from '@/pages/TimeAttendancePage';
import LeaveManagementPage from '@/pages/LeaveManagementPage';
import NotFoundPage from '@/pages/NotFoundPage';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <Router>
      <Toaster />
      <Routes>
        <Route path="/" element={<DashboardLayout />}>
          <Route index element={<Navigate to="/employee-profiles" replace />} />
          <Route path="employee-profiles" element={<EmployeeProfilesPage />} />
          <Route path="time-attendance" element={<TimeAttendancePage />} />
          <Route path="leave-management" element={<LeaveManagementPage />} />
        </Route>
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Router>
  );
}

export default App;