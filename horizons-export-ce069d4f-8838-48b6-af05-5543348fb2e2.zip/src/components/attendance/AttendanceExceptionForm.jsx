import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const AttendanceExceptionForm = ({
  isOpen,
  setIsOpen,
  currentException,
  handleInputChange,
  handleSelectChange,
  handleSubmit,
  employees,
  exceptionTypes,
  exceptionStatusTypes,
  isEditing = false // Though not used in current simplified version, good for future
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg bg-card/95 backdrop-blur-xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-orange-500 to-red-500">Record Absence</DialogTitle>
          <DialogDescription>
            Log an absence for an employee.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div>
            <Label htmlFor="employee_id" className="mb-1">Employee</Label>
            <Select name="employee_id" onValueChange={(value) => handleSelectChange("employee_id", value)} value={currentException.employee_id}>
              <SelectTrigger id="employee_id" className="w-full">
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>{emp.name} ({emp.employee_id})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="date" className="mb-1">Date of Absence</Label>
            <Input type="date" id="date" name="date" value={currentException.date} onChange={handleInputChange} className="w-full" />
          </div>
          <div>
            <Label htmlFor="exception_type" className="mb-1">Absence Type</Label>
            <Select name="exception_type" onValueChange={(value) => handleSelectChange("exception_type", value)} value={currentException.exception_type}>
              <SelectTrigger id="exception_type" className="w-full">
                <SelectValue placeholder="Select absence type" />
              </SelectTrigger>
              <SelectContent>
                {exceptionTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="details" className="mb-1">Details / Notes</Label>
            <Textarea id="details" name="details" placeholder="Provide any additional details (e.g., reason for sick leave)..." value={currentException.details} onChange={handleInputChange} className="w-full min-h-[100px]" />
          </div>
           <div>
            <Label htmlFor="status" className="mb-1">Status</Label>
            <Select name="status" onValueChange={(value) => handleSelectChange("status", value)} value={currentException.status}>
              <SelectTrigger id="status" className="w-full">
                <SelectValue placeholder="Set status" />
              </SelectTrigger>
              <SelectContent>
                {exceptionStatusTypes.map(status => (
                  <SelectItem key={status} value={status}>{status}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        <DialogFooter className="pt-4">
          <DialogClose asChild>
            <Button type="button" variant="outline">Cancel</Button>
          </DialogClose>
          <Button type="submit" className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-500/90 hover:to-red-500/90 text-white">Save Absence</Button>
        </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AttendanceExceptionForm;