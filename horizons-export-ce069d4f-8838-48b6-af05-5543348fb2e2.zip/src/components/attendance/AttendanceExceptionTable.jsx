import React from 'react';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Clock, AlertTriangle } from 'lucide-react';

const AttendanceExceptionTable = ({ exceptions, isLoading, searchTerm, filterType, filterStatus }) => {
  const getBadgeVariant = (status) => {
    switch (status) {
      case 'Pending': return 'warning';
      case 'Reviewed': return 'outline';
      case 'Resolved': return 'success';
      default: return 'secondary';
    }
  };

  if (isLoading) {
    return <div className="text-center py-10"><Clock className="mx-auto h-12 w-12 text-primary animate-spin" /> Loading absences...</div>;
  }

  if (exceptions.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground">
        <AlertTriangle className="mx-auto h-12 w-12 mb-4 text-orange-400" />
        <p className="font-semibold">No absences found.</p>
        <p className="text-sm">{searchTerm || filterType !== 'all' || filterStatus !== 'all' ? "Try adjusting your search or filters." : "No absences recorded yet."}</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead className="hidden md:table-cell">Details</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden lg:table-cell">Reported At</TableHead>
            {/* Add actions column if needed for edit/delete in future */}
          </TableRow>
        </TableHeader>
        <TableBody>
          {exceptions.map(ex => (
            <TableRow key={ex.id}>
              <TableCell>
                <div className="font-medium">{ex.employees?.name || 'N/A'}</div>
                <div className="text-xs text-muted-foreground">{ex.employees?.employee_id || 'N/A'}</div>
              </TableCell>
              <TableCell>{new Date(ex.date).toLocaleDateString()}</TableCell>
              <TableCell>{ex.exception_type}</TableCell>
              <TableCell className="hidden md:table-cell max-w-xs truncate">{ex.details || 'N/A'}</TableCell>
              <TableCell>
                <Badge variant={getBadgeVariant(ex.status)}>{ex.status}</Badge>
              </TableCell>
              <TableCell className="hidden lg:table-cell">{new Date(ex.reported_at).toLocaleString()}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default AttendanceExceptionTable;