import React from 'react';
import { Button } from '@/components/ui/button';
import { PlusCircle, Users } from 'lucide-react';
import { motion } from 'framer-motion';

const EmptyState = ({ onAddEmployee, itemVariants }) => {
  return (
    <motion.div 
      variants={itemVariants} 
      className="text-center py-10 text-muted-foreground"
    >
      <Users className="mx-auto h-16 w-16 mb-4 text-primary/50" />
      <h3 className="text-xl font-semibold mb-2 text-foreground">No Employees Yet</h3>
      <p className="mb-4">Start by adding your first employee to the system.</p>
      <Button onClick={onAddEmployee} variant="outline" className="border-primary/50 text-primary hover:bg-primary/10 hover:text-primary transition-colors">
        <PlusCircle className="mr-2 h-4 w-4" /> Add Employee
      </Button>
    </motion.div>
  );
};

export default EmptyState;