import React from 'react';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
} from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const EmployeeTable = ({ employees, onEdit, onDelete }) => {
  if (!employees || employees.length === 0) {
    return null; 
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent dark:hover:bg-transparent">
            <TableHead className="w-[80px]">Avatar</TableHead>
            <TableHead>Name</TableHead>
            <TableHead className="hidden md:table-cell">Email</TableHead>
            <TableHead>Role</TableHead>
            <TableHead className="hidden lg:table-cell">Department</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <AnimatePresence>
            {employees.map((employee, index) => (
              <motion.tr
                key={employee.id}
                layout
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors duration-150"
              >
                <TableCell>
                  <Avatar className="w-12 h-12 border-2 border-primary/20">
                    <AvatarImage src={employee.photo_url || `https://ui-avatars.com/api/?name=${employee.name}&background=random`} alt={employee.name} />
                    <AvatarFallback>{employee.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                </TableCell>
                <TableCell className="font-medium text-foreground">{employee.name}</TableCell>
                <TableCell className="hidden md:table-cell text-muted-foreground">{employee.email}</TableCell>
                <TableCell className="text-foreground">{employee.role}</TableCell>
                <TableCell className="hidden lg:table-cell text-muted-foreground">{employee.department || 'N/A'}</TableCell>
                <TableCell className="text-right space-x-1 sm:space-x-2">
                  <Button variant="ghost" size="icon" onClick={() => onEdit(employee)} className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 transition-colors">
                    <Edit className="h-4 w-4 sm:h-5 sm:w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => onDelete(employee.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                    <Trash2 className="h-4 w-4 sm:h-5 sm:w-5" />
                  </Button>
                </TableCell>
              </motion.tr>
            ))}
          </AnimatePresence>
        </TableBody>
        {employees.length > 5 && <TableCaption>A list of your current employees.</TableCaption>}
      </Table>
    </div>
  );
};

export default EmployeeTable;