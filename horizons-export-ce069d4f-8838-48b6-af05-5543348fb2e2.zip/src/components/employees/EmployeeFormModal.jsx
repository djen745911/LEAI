import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  DialogClose
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/components/ui/use-toast';
import { UserCircle, Briefcase, PhoneCall, Banknote, Users, Info, Settings } from 'lucide-react';

import PersonalDetailsFields from './formTabs/PersonalDetailsFields';
import EmploymentDetailsFields from './formTabs/EmploymentDetailsFields';
import ContactDetailsFields from './formTabs/ContactDetailsFields';
import EmergencyContactFields from './formTabs/EmergencyContactFields';
import PayrollFields from './formTabs/PayrollFields';
import OptionalFields from './formTabs/OptionalFields';
import SystemFields from './formTabs/SystemFields';

const initialEmployeeState = {
  id: null, name: '', photo_url: null, preferred_name: '', title: '', date_of_birth: '', gender: '', pronouns: '',
  national_insurance_number: '', nationality: '', passport_number: '', visa_status: '', visa_expiry: '',
  personal_email: '', work_email: '', mobile_phone_number: '', landline_phone_number: '',
  home_address_street: '', home_address_city: '', home_address_postcode: '', home_address_country: '',
  mailing_address_street: '', mailing_address_city: '', mailing_address_postcode: '', mailing_address_country: '',
  employee_id: '', job_title: '', department: '', team: '', manager_supervisor: '', employment_type: '',
  start_date: '', end_date: '', work_location: '', grade_band_level: '', cost_centre: '', project_code: '', payroll_id: '',
  emergency_contact_name: '', emergency_contact_relationship: '', emergency_contact_phone: '',
  secondary_emergency_contact_name: '', secondary_emergency_contact_relationship: '', secondary_emergency_contact_phone: '',
  bank_name: '', account_number: '', sort_code: '', iban: '', swift_code: '', tax_code: '', pension_scheme_info: '',
  next_of_kin_name: '', next_of_kin_relationship: '', next_of_kin_contact_details: '',
  ethnicity: '', religion: '', sexual_orientation: '', disability_requirements: '', marital_status: '',
  number_of_dependants: '', preferred_language: '', t_shirt_size: '', dietary_requirements: '',
  allergies_medical_info: '', user_role: '', account_status: 'Active', notes: ''
};

const EmployeeFormModal = ({ isOpen, setIsOpen, currentEmployee, isEditing, onFormSubmit }) => {
  const [employeeData, setEmployeeData] = useState(initialEmployeeState);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("personal");

  const employeeIdBase = useMemo(() => {
    if (employeeData.name && employeeData.start_date) {
      const namePart = employeeData.name.substring(0, 3).toUpperCase();
      const datePart = employeeData.start_date.substring(2, 4) + employeeData.start_date.substring(5, 7);
      return `${namePart}${datePart}`;
    }
    return 'EMP';
  }, [employeeData.name, employeeData.start_date]);

  useEffect(() => {
    if (currentEmployee) {
      const loadedData = { ...initialEmployeeState, ...currentEmployee };
      ['date_of_birth', 'visa_expiry', 'start_date', 'end_date'].forEach(field => {
        if (loadedData[field]) {
          loadedData[field] = new Date(loadedData[field]).toISOString().split('T')[0];
        } else {
          loadedData[field] = ''; // Ensure null dates are empty strings for input[type=date]
        }
      });
      if (loadedData.number_of_dependants === null || typeof loadedData.number_of_dependants === 'undefined') {
        loadedData.number_of_dependants = '';
      }
      setEmployeeData(loadedData);
      setPreviewUrl(currentEmployee.photo_url || null);
    } else {
      const newEmployeeId = `${employeeIdBase}${Math.floor(100 + Math.random() * 900)}`;
      setEmployeeData({...initialEmployeeState, employee_id: newEmployeeId, account_status: 'Active'});
      setPreviewUrl(null);
    }
    setSelectedFile(null);
    setActiveTab("personal");
  }, [currentEmployee, isOpen, employeeIdBase]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setEmployeeData({ ...employeeData, [name]: type === 'checkbox' ? checked : value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadPhoto = async () => {
    if (!selectedFile) return employeeData.photo_url;
    setIsUploading(true);

    const fileExt = selectedFile.name.split('.').pop();
    const fileName = `${employeeData.employee_id || Date.now()}_${Date.now()}.${fileExt}`;
    const filePath = `public/${fileName}`;

    try {
      await supabase.storage
        .from('employee_photos')
        .upload(filePath, selectedFile, {
            cacheControl: '3600',
            upsert: true 
        });
      
      const { data: publicURLData } = supabase.storage.from('employee_photos').getPublicUrl(filePath);
      setIsUploading(false);
      return publicURLData.publicUrl;

    } catch (error) {
      console.error('Error uploading photo:', error);
      toast({
        variant: "destructive",
        title: "Photo Upload Failed",
        description: error.message || "Could not upload the employee photo.",
      });
      setIsUploading(false);
      return employeeData.photo_url; 
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!employeeData.name || !employeeData.work_email || !employeeData.job_title || !employeeData.employee_id) {
      toast({
        variant: "destructive",
        title: "Missing Core Fields",
        description: "Please fill in Name, Work Email, Job Title, and Employee ID.",
      });
      let targetTab = "personal";
      if (!employeeData.name) targetTab = "personal";
      else if (!employeeData.work_email) targetTab = "contact";
      else if (!employeeData.job_title || !employeeData.employee_id) targetTab = "employment";
      setActiveTab(targetTab);
      return;
    }

    let photoUrlToSave = employeeData.photo_url;
    if (selectedFile) {
      photoUrlToSave = await uploadPhoto();
      if (!photoUrlToSave && selectedFile) { // If upload failed but a file was selected, stop.
        return;
      }
    }
    
    const processedEmployeeData = { ...employeeData, photo_url: photoUrlToSave };
    for (const key in processedEmployeeData) {
      if (processedEmployeeData[key] === '') {
        processedEmployeeData[key] = null;
      }
      if (key === 'number_of_dependants' && processedEmployeeData[key] !== null) {
        const numDependants = parseInt(processedEmployeeData[key], 10);
        processedEmployeeData[key] = isNaN(numDependants) ? null : numDependants;
      }
    }
    
    onFormSubmit(processedEmployeeData, isEditing);
  };
  
  const renderField = (id, label, type = "text", props = {}) => (
    <div className="grid gap-2">
      <Label htmlFor={id} className={props.required ? "after:content-['*'] after:ml-0.5 after:text-red-500" : ""}>{label}</Label>
      <Input id={id} name={id} type={type} value={employeeData[id] || ''} onChange={handleInputChange} {...props} className="bg-background/70" />
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-3xl md:max-w-4xl lg:max-w-5xl xl:max-w-6xl bg-card/95 backdrop-blur-xl border-border/70 shadow-2xl rounded-xl max-h-[90vh] flex flex-col">
        <DialogHeader className="pt-6 px-6">
          <DialogTitle className="text-2xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-400">
            {isEditing ? 'Edit Employee Details' : 'Add New Employee'}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            {isEditing ? "Update the employee's information." : "Fill in the details for the new employee."}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} id="employee-form-id" className="flex-grow overflow-y-auto px-6 pb-1 grid gap-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col min-h-0">
            <TabsList className="grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-7 mb-4 bg-muted/50 p-1 rounded-lg sticky top-0 z-10">
              <TabsTrigger value="personal" className="flex items-center gap-1 text-xs sm:text-sm"><UserCircle size={16}/>Personal</TabsTrigger>
              <TabsTrigger value="employment" className="flex items-center gap-1 text-xs sm:text-sm"><Briefcase size={16}/>Employment</TabsTrigger>
              <TabsTrigger value="contact" className="flex items-center gap-1 text-xs sm:text-sm"><PhoneCall size={16}/>Contact</TabsTrigger>
              <TabsTrigger value="emergency" className="flex items-center gap-1 text-xs sm:text-sm"><Users size={16}/>Emergency</TabsTrigger>
              <TabsTrigger value="payroll" className="flex items-center gap-1 text-xs sm:text-sm"><Banknote size={16}/>Payroll</TabsTrigger>
              <TabsTrigger value="optional" className="flex items-center gap-1 text-xs sm:text-sm"><Info size={16}/>Optional</TabsTrigger>
              <TabsTrigger value="system" className="flex items-center gap-1 text-xs sm:text-sm"><Settings size={16}/>System</TabsTrigger>
            </TabsList>

            <div className="flex-grow overflow-y-auto pr-2 -mr-2 pb-4 custom-scrollbar">
              <TabsContent value="personal">
                <PersonalDetailsFields 
                  employeeData={employeeData} 
                  renderField={renderField}
                  previewUrl={previewUrl}
                  selectedFile={selectedFile}
                  handleFileChange={handleFileChange}
                />
              </TabsContent>
              <TabsContent value="employment">
                <EmploymentDetailsFields 
                  employeeData={employeeData}
                  renderField={renderField}
                  isEditing={isEditing}
                />
              </TabsContent>
              <TabsContent value="contact">
                <ContactDetailsFields
                  employeeData={employeeData}
                  renderField={renderField}
                />
              </TabsContent>
              <TabsContent value="emergency">
                <EmergencyContactFields
                  employeeData={employeeData}
                  renderField={renderField}
                />
              </TabsContent>
              <TabsContent value="payroll">
                <PayrollFields
                  employeeData={employeeData}
                  renderField={renderField}
                />
              </TabsContent>
              <TabsContent value="optional">
                <OptionalFields
                  employeeData={employeeData}
                  renderField={renderField}
                />
              </TabsContent>
              <TabsContent value="system">
                <SystemFields
                  employeeData={employeeData}
                  handleInputChange={handleInputChange}
                  renderField={renderField}
                />
              </TabsContent>
            </div>
          </Tabs>
        </form>

        <DialogFooter className="mt-auto pt-4 px-6 pb-6 border-t border-border/50 sticky bottom-0 bg-card/95 z-10">
          <DialogClose asChild>
            <Button type="button" variant="outline">Cancel</Button>
          </DialogClose>
          <Button 
            type="submit" 
            form="employee-form-id" 
            disabled={isUploading} 
            className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-500/90 text-white shadow-md hover:shadow-lg transition-shadow"
          >
            {isUploading ? 'Uploading...' : (isEditing ? 'Save Changes' : 'Add Employee')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EmployeeFormModal;