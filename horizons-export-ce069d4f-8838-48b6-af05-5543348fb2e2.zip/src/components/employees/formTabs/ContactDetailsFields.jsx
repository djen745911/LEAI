import React from 'react';
import { Label } from '@/components/ui/label';

const ContactDetailsFields = ({ employeeData, renderField }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-0">
      {renderField("personal_email", "Personal Email", "email")}
      {renderField("work_email", "Work Email", "email", { required: true })}
      {renderField("mobile_phone_number", "Mobile Phone Number", "tel")}
      {renderField("landline_phone_number", "Landline Phone Number", "tel")}
      <div className="md:col-span-2 grid gap-2">
        <Label>Home Address</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 p-3 border rounded-md bg-background/20">
          {renderField("home_address_street", "Street", "text", { placeholder: "123 Main St" })}
          {renderField("home_address_city", "City", "text", { placeholder: "Anytown" })}
          {renderField("home_address_postcode", "Postcode", "text", { placeholder: "12345" })}
          {renderField("home_address_country", "Country", "text", { placeholder: "USA" })}
        </div>
      </div>
        <div className="md:col-span-2 grid gap-2">
        <Label>Mailing Address (if different)</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 p-3 border rounded-md bg-background/20">
          {renderField("mailing_address_street", "Street", "text")}
          {renderField("mailing_address_city", "City", "text")}
          {renderField("mailing_address_postcode", "Postcode", "text")}
          {renderField("mailing_address_country", "Country", "text")}
        </div>
      </div>
    </div>
  );
};

export default ContactDetailsFields;