import React from 'react';

const OptionalFields = ({ employeeData, renderField }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-0">
      {renderField("ethnicity", "Ethnicity", "text")}
      {renderField("religion", "Religion", "text")}
      {renderField("sexual_orientation", "Sexual Orientation", "text")}
      {renderField("disability_requirements", "Disability / Accessibility Requirements", "text")}
      {renderField("marital_status", "Marital Status", "text")}
      {renderField("number_of_dependants", "Number of Dependants / Children", "number", { min: "0", step: "1"})}
      {renderField("preferred_language", "Preferred Language", "text")}
      {renderField("t_shirt_size", "T-shirt Size", "text")}
      {renderField("dietary_requirements", "Dietary Requirements (for events)", "text")}
      {renderField("allergies_medical_info", "Allergies / Medical Info (for events)", "text")}
    </div>
  );
};

export default OptionalFields;