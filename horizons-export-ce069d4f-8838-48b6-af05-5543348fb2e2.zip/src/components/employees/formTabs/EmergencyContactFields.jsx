import React from 'react';

const EmergencyContactFields = ({ employeeData, renderField }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-0">
      <div className="space-y-4 p-4 border rounded-lg bg-background/20">
          <h3 className="text-lg font-medium text-primary">Primary Emergency Contact</h3>
          {renderField("emergency_contact_name", "Name", "text")}
          {renderField("emergency_contact_relationship", "Relationship", "text")}
          {renderField("emergency_contact_phone", "Phone Number", "tel")}
      </div>
      <div className="space-y-4 p-4 border rounded-lg bg-background/20">
          <h3 className="text-lg font-medium text-primary">Secondary Emergency Contact</h3>
          {renderField("secondary_emergency_contact_name", "Name", "text")}
          {renderField("secondary_emergency_contact_relationship", "Relationship", "text")}
          {renderField("secondary_emergency_contact_phone", "Phone Number", "tel")}
      </div>
        <div className="space-y-4 p-4 border rounded-lg bg-background/20 md:col-span-2">
          <h3 className="text-lg font-medium text-primary">Next of Kin</h3>
          {renderField("next_of_kin_name", "Name", "text")}
          {renderField("next_of_kin_relationship", "Relationship", "text")}
          {renderField("next_of_kin_contact_details", "Contact Details (Phone/Email)", "text")}
      </div>
    </div>
  );
};

export default EmergencyContactFields;