import React from 'react';

const EmploymentDetailsFields = ({ employeeData, renderField, isEditing }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-0">
      {renderField("employee_id", "Employee ID", "text", { placeholder: "Auto-generated or manual", required: true, disabled: isEditing })}
      {renderField("job_title", "Job Title", "text", { required: true })}
      {renderField("department", "Department / Main Team", "text")}
      {renderField("team", "Specific Team (if any)", "text")}
      {renderField("manager_supervisor", "Manager / Supervisor", "text")}
      {renderField("employment_type", "Employment Type", "text", { placeholder: "Permanent, Contractor, etc." })}
      {renderField("start_date", "Start Date", "date")}
      {renderField("end_date", "End Date (if applicable)", "date")}
      {renderField("work_location", "Work Location", "text", { placeholder: "Office, Remote, Hybrid" })}
      {renderField("grade_band_level", "Grade / Band / Level", "text")}
      {renderField("cost_centre", "Cost Centre", "text")}
      {renderField("project_code", "Project Code", "text")}
    </div>
  );
};

export default EmploymentDetailsFields;