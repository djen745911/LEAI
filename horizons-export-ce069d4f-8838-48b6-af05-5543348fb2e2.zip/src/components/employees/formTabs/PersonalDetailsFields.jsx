import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { UploadCloud } from 'lucide-react';

const PersonalDetailsFields = ({ employeeData, renderField, previewUrl, selectedFile, handleFileChange }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-0">
      <div className="lg:col-span-3 flex flex-col items-center gap-4 mb-6 p-4 border rounded-lg bg-background/30">
        <Avatar className="w-32 h-32 border-4 border-primary/30 shadow-lg">
          <AvatarImage src={previewUrl || `https://ui-avatars.com/api/?name=${employeeData.name || 'N A'}&background=random&size=128`} alt={employeeData.name} />
          <AvatarFallback className="text-3xl">{employeeData.name ? employeeData.name.substring(0,2).toUpperCase() : '??'}</AvatarFallback>
        </Avatar>
        <div className="grid w-full max-w-sm items-center gap-1.5">
          <Label htmlFor="picture" className="text-sm font-medium text-foreground flex items-center justify-center gap-2 cursor-pointer hover:text-primary transition-colors">
            <UploadCloud className="w-5 h-5" />
            {selectedFile ? 'Change Photo' : 'Upload Photo'}
          </Label>
          <Input id="picture" type="file" onChange={handleFileChange} className="text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer" accept="image/png, image/jpeg, image/jpg" />
          {selectedFile && <p className="text-xs text-muted-foreground mt-1 text-center">Selected: {selectedFile.name}</p>}
        </div>
      </div>
      {renderField("name", "Full Name", "text", { placeholder: "First Middle Last", required: true })}
      {renderField("preferred_name", "Preferred Name", "text", { placeholder: "Nickname" })}
      {renderField("title", "Title", "text", { placeholder: "Mr/Ms/Dr" })}
      {renderField("date_of_birth", "Date of Birth", "date")}
      {renderField("gender", "Gender", "text", { placeholder: "e.g. Male, Female, Non-binary" })}
      {renderField("pronouns", "Pronouns", "text", { placeholder: "e.g. she/her, he/him, they/them" })}
      {renderField("national_insurance_number", "National Insurance Number / SSN", "text")}
      {renderField("nationality", "Nationality", "text")}
      {renderField("passport_number", "Passport Number", "text")}
      {renderField("visa_status", "Visa/Work Permit Status", "text")}
      {renderField("visa_expiry", "Visa Expiry Date", "date")}
    </div>
  );
};

export default PersonalDetailsFields;