import React from 'react';
import { Label } from '@/components/ui/label';

const SystemFields = ({ employeeData, handleInputChange, renderField }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-0">
      {renderField("user_role", "User Role / Access Level", "text", { placeholder: "e.g. Employee, Manager, Admin" })}
      <div className="grid gap-2">
          <Label htmlFor="account_status">Account Status</Label>
          <select 
              id="account_status" 
              name="account_status" 
              value={employeeData.account_status || 'Active'} 
              onChange={handleInputChange} 
              className="bg-background/70 border border-input rounded-md px-3 py-2 text-sm h-10"
          >
              <option value="Active">Active</option>
              <option value="On Leave">On Leave</option>
              <option value="Offboarded">Offboarded</option>
              <option value="Pending">Pending</option>
          </select>
      </div>
      <div className="grid gap-2 md:col-span-2 lg:col-span-3">
        <Label htmlFor="notes">Notes / Comments</Label>
        <textarea 
          id="notes" 
          name="notes" 
          value={employeeData.notes || ''} 
          onChange={handleInputChange} 
          placeholder="Any additional notes about the employee..."
          rows={4}
          className="bg-background/70 border border-input rounded-md px-3 py-2 text-sm w-full"
        />
      </div>
    </div>
  );
};

export default SystemFields;