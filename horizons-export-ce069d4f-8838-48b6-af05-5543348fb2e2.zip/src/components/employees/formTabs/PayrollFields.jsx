import React from 'react';

const PayrollFields = ({ employeeData, renderField }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-0">
      {renderField("payroll_id", "Payroll ID / Reference", "text")}
      {renderField("bank_name", "Bank Name", "text")}
      {renderField("account_number", "Account Number", "text")}
      {renderField("sort_code", "Sort Code / Routing Number", "text")}
      {renderField("iban", "IBAN", "text")}
      {renderField("swift_code", "SWIFT/BIC Code", "text")}
      {renderField("tax_code", "Tax Code", "text")}
      {renderField("pension_scheme_info", "Pension Scheme Info", "text")}
    </div>
  );
};

export default PayrollFields;