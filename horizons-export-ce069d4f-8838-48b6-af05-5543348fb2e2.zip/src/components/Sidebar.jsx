import React from 'react';
import { NavLink } from 'react-router-dom';
import { Users, Clock, CalendarDays, Briefcase } from 'lucide-react';
import { motion } from 'framer-motion';

const navItems = [
  { to: "/employee-profiles", icon: Users, label: "Employees" },
  { to: "/time-attendance", icon: Clock, label: "Time & Attendance" },
  { to: "/leave-management", icon: CalendarDays, label: "Leave Management" },
];

const Sidebar = () => {
  return (
    <motion.aside 
      initial={{ x: -250 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.5, type: 'spring', stiffness: 100 }}
      className="w-64 bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 p-6 flex flex-col space-y-8 shadow-2xl min-h-screen"
    >
      <div className="flex items-center space-x-3 mb-8">
        <Briefcase className="h-10 w-10 text-primary" />
        <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary via-purple-400 to-pink-500">EMS</h1>
      </div>
      <nav className="flex-grow">
        <ul className="space-y-3">
          {navItems.map((item, index) => (
            <motion.li 
              key={item.to}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.2 + index * 0.1 }}
            >
              <NavLink
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center space-x-3 p-3 rounded-lg transition-all duration-300 ease-in-out group hover:bg-primary/20 hover:shadow-lg
                  ${isActive ? "bg-primary text-primary-foreground shadow-md scale-105" : "text-slate-300 hover:text-slate-50"}`
                }
              >
                {({ isActive }) => (
                  <>
                    <item.icon className={`h-5 w-5 transition-transform duration-300 group-hover:scale-110 ${isActive ? "" : "text-primary/80"}`} />
                    <span className="font-medium">{item.label}</span>
                  </>
                )}
              </NavLink>
            </motion.li>
          ))}
        </ul>
      </nav>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="mt-auto text-center text-xs text-slate-500"
      >
        <p>&copy; {new Date().getFullYear()} EMS Inc.</p>
        <p>Version 0.0.1</p>
      </motion.div>
    </motion.aside>
  );
};

export default Sidebar;
