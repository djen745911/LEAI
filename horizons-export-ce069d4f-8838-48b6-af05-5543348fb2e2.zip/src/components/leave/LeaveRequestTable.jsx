import React from 'react';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, CheckCircle, XCircle, Trash2, Edit3, CalendarClock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const LeaveRequestTable = ({ requests, isLoading, onUpdateRequestStatus, onEditRequest, onDeleteRequest, currentUserId /* Assuming we can get current user ID for ownership checks */ }) => {
  const { toast } = useToast();

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'Pending': return 'warning';
      case 'Approved': return 'success';
      case 'Declined': return 'destructive';
      case 'Cancelled': return 'secondary';
      default: return 'outline';
    }
  };

  const handleStatusUpdate = (id, newStatus) => {
    onUpdateRequestStatus(id, newStatus);
  };
  
  const canCancel = (request) => {
    // Example: User can cancel their own pending requests
    // return request.employee_id === currentUserId && request.status === 'Pending';
    // For now, let's assume an admin can cancel any pending request
    return request.status === 'Pending' || request.status === 'Approved';
  };

  const canApproveDecline = (request) => {
    // Example: Only managers or admins can approve/decline
    // This would need role-based logic. For now, assume true for demo.
    return request.status === 'Pending';
  };


  if (isLoading) {
    return <div className="text-center py-10"><CalendarClock className="mx-auto h-12 w-12 text-primary animate-spin" /> Loading leave requests...</div>;
  }

  if (!requests || requests.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground">
        <CalendarClock className="mx-auto h-12 w-12 mb-4 text-primary/40" />
        <p className="font-semibold">No leave requests found.</p>
        <p className="text-sm">Submit a new leave request to see it here.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead className="hidden md:table-cell">Reason</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden lg:table-cell">Requested At</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {requests.map(req => (
            <TableRow key={req.id}>
              <TableCell>
                <div className="font-medium">{req.employees?.name || 'N/A'}</div>
                <div className="text-xs text-muted-foreground">{req.employees?.employee_id || 'N/A'}</div>
              </TableCell>
              <TableCell>{req.leave_type}</TableCell>
              <TableCell>{new Date(req.start_date).toLocaleDateString()}</TableCell>
              <TableCell>{new Date(req.end_date).toLocaleDateString()}</TableCell>
              <TableCell className="hidden md:table-cell max-w-xs truncate">{req.reason || 'N/A'}</TableCell>
              <TableCell>
                <Badge variant={getStatusBadgeVariant(req.status)}>{req.status}</Badge>
              </TableCell>
              <TableCell className="hidden lg:table-cell">{new Date(req.created_at).toLocaleDateString()}</TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {canApproveDecline(req) && (
                      <>
                        <DropdownMenuItem onClick={() => handleStatusUpdate(req.id, 'Approved')}>
                          <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Approve
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusUpdate(req.id, 'Declined')}>
                          <XCircle className="mr-2 h-4 w-4 text-red-500" /> Decline
                        </DropdownMenuItem>
                      </>
                    )}
                    {/* For now, edit is available for pending requests by anyone for demo */}
                    {req.status === 'Pending' && (
                       <DropdownMenuItem onClick={() => onEditRequest(req)}>
                        <Edit3 className="mr-2 h-4 w-4 text-blue-500" /> Edit
                      </DropdownMenuItem>
                    )}
                    {canCancel(req) && (
                      <DropdownMenuItem onClick={() => handleStatusUpdate(req.id, 'Cancelled')}>
                        <Trash2 className="mr-2 h-4 w-4 text-gray-500" /> Cancel Request
                      </DropdownMenuItem>
                    )}
                     {/* Add delete option if needed, typically for admins or if request is not yet processed */}
                    {/* <DropdownMenuItem onClick={() => onDeleteRequest(req.id)} className="text-red-600 hover:!text-red-600">
                      <Trash2 className="mr-2 h-4 w-4" /> Delete
                    </DropdownMenuItem> */}
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default LeaveRequestTable;