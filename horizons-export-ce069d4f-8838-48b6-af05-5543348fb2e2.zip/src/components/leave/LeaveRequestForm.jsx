import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from '@/components/ui/use-toast';

const initialLeaveRequestState = {
  employee_id: '',
  leave_type: '',
  start_date: new Date().toISOString().split('T')[0],
  end_date: new Date().toISOString().split('T')[0],
  reason: '',
  status: 'Pending', 
};

const LeaveRequestForm = ({
  isOpen,
  setIsOpen,
  onSubmit,
  employees,
  currentRequest: initialCurrentRequest, // Renamed to avoid conflict
  isEditing = false
}) => {
  const [currentRequest, setCurrentRequest] = useState(initialLeaveRequestState);
  const { toast } = useToast();

  const leaveTypes = [
    { value: "Annual Leave", label: "Annual Leave" },
    { value: "Sick Leave", label: "Sick Leave" },
    { value: "Unpaid Leave", label: "Unpaid Leave" },
    { value: "Maternity/Paternity Leave", label: "Maternity/Paternity Leave" },
    { value: "Bereavement Leave", label: "Bereavement Leave" },
    { value: "Other", label: "Other" },
  ];

  useEffect(() => {
    if (isEditing && initialCurrentRequest) {
      setCurrentRequest({
        ...initialCurrentRequest,
        start_date: initialCurrentRequest.start_date ? new Date(initialCurrentRequest.start_date).toISOString().split('T')[0] : '',
        end_date: initialCurrentRequest.end_date ? new Date(initialCurrentRequest.end_date).toISOString().split('T')[0] : '',
      });
    } else {
      setCurrentRequest(initialLeaveRequestState);
    }
  }, [isOpen, isEditing, initialCurrentRequest]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentRequest(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setCurrentRequest(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!currentRequest.employee_id || !currentRequest.leave_type || !currentRequest.start_date || !currentRequest.end_date) {
      toast({ variant: "destructive", title: "Missing Fields", description: "Employee, Leave Type, Start Date, and End Date are required." });
      return;
    }
    if (new Date(currentRequest.start_date) > new Date(currentRequest.end_date)) {
      toast({ variant: "destructive", title: "Invalid Dates", description: "Start Date cannot be after End Date." });
      return;
    }
    onSubmit(currentRequest, isEditing);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-lg bg-card/95 backdrop-blur-xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500">
            {isEditing ? 'Edit Leave Request' : 'Submit New Leave Request'}
          </DialogTitle>
          <DialogDescription>
            {isEditing ? 'Update the details of the leave request.' : 'Fill in the details to request time off.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div>
            <Label htmlFor="employee_id" className="mb-1">Employee</Label>
            <Select name="employee_id" onValueChange={(value) => handleSelectChange("employee_id", value)} value={currentRequest.employee_id}>
              <SelectTrigger id="employee_id" className="w-full">
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>{emp.name} ({emp.employee_id})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="leave_type" className="mb-1">Leave Type</Label>
            <Select name="leave_type" onValueChange={(value) => handleSelectChange("leave_type", value)} value={currentRequest.leave_type}>
              <SelectTrigger id="leave_type" className="w-full">
                <SelectValue placeholder="Select leave type" />
              </SelectTrigger>
              <SelectContent>
                {leaveTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="start_date" className="mb-1">Start Date</Label>
              <Input type="date" id="start_date" name="start_date" value={currentRequest.start_date} onChange={handleInputChange} className="w-full" />
            </div>
            <div>
              <Label htmlFor="end_date" className="mb-1">End Date</Label>
              <Input type="date" id="end_date" name="end_date" value={currentRequest.end_date} onChange={handleInputChange} className="w-full" />
            </div>
          </div>
          <div>
            <Label htmlFor="reason" className="mb-1">Reason (Optional)</Label>
            <Textarea id="reason" name="reason" placeholder="Provide a brief reason for your leave..." value={currentRequest.reason} onChange={handleInputChange} className="w-full min-h-[100px]" />
          </div>
          {isEditing && (
             <div>
              <Label htmlFor="status" className="mb-1">Status</Label>
              <Select name="status" onValueChange={(value) => handleSelectChange("status", value)} value={currentRequest.status}>
                <SelectTrigger id="status" className="w-full">
                  <SelectValue placeholder="Set status" />
                </SelectTrigger>
                <SelectContent>
                  {["Pending", "Approved", "Declined", "Cancelled"].map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <DialogFooter className="pt-4">
            <DialogClose asChild>
              <Button type="button" variant="outline">Cancel</Button>
            </DialogClose>
            <Button type="submit" className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-500/90 text-white">
              {isEditing ? 'Save Changes' : 'Submit Request'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default LeaveRequestForm;