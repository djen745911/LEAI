import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';
import { CalendarPlus, Search, Filter, CalendarDays } from 'lucide-react';
import { motion } from 'framer-motion';
import LeaveRequestForm from '@/components/leave/LeaveRequestForm';
import LeaveRequestTable from '@/components/leave/LeaveRequestTable';

const initialLeaveRequestState = {
  id: null, // for editing
  employee_id: '',
  leave_type: '',
  start_date: new Date().toISOString().split('T')[0],
  end_date: new Date().toISOString().split('T')[0],
  reason: '',
  status: 'Pending',
};

const leaveStatusTypes = ["All", "Pending", "Approved", "Declined", "Cancelled"];
const leaveTypesForFilter = ["All", "Annual Leave", "Sick Leave", "Unpaid Leave", "Maternity/Paternity Leave", "Bereavement Leave", "Other"];


const LeaveManagementPage = () => {
  const [employees, setEmployees] = useState([]);
  const [leaveRequests, setLeaveRequests] = useState([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentRequest, setCurrentRequest] = useState(initialLeaveRequestState);
  const [isEditing, setIsEditing] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterLeaveType, setFilterLeaveType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');

  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data: employeesData, error: employeesError } = await supabase.from('employees').select('id, name, employee_id');
      if (employeesError) throw employeesError;
      setEmployees(employeesData || []);

      let query = supabase
        .from('leave_requests')
        .select(`
          *, 
          employees!leave_requests_employee_id_fkey (name, employee_id)
        `);
      
      if (filterLeaveType !== 'All') {
        query = query.eq('leave_type', filterLeaveType);
      }
      if (filterStatus !== 'All') {
        query = query.eq('status', filterStatus);
      }
      
      if (searchTerm) {
        // Corrected .or() syntax and specified join for employee name search
        query = query.or(`reason.ilike.%${searchTerm}%,employees!leave_requests_employee_id_fkey.name.ilike.%${searchTerm}%`);
      }

      query = query.order('created_at', { ascending: false });
      
      const { data: requestsData, error: requestsError } = await query;

      if (requestsError) {
        console.error("Fetch error from Supabase:", requestsError);
        throw requestsError;
      }
      setLeaveRequests(requestsData || []);
      
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({ variant: "destructive", title: "Failed to load data", description: error.message });
    }
    setIsLoading(false);
  }, [toast, filterLeaveType, filterStatus, searchTerm]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleOpenModal = (requestToEdit = null) => {
    if (requestToEdit) {
      setCurrentRequest(requestToEdit);
      setIsEditing(true);
    } else {
      setCurrentRequest(initialLeaveRequestState);
      setIsEditing(false);
    }
    setIsModalOpen(true);
  };

  const handleFormSubmit = async (requestData, editing) => {
    const dataToSave = {
      employee_id: requestData.employee_id,
      leave_type: requestData.leave_type,
      start_date: requestData.start_date,
      end_date: requestData.end_date,
      reason: requestData.reason || null,
      status: editing ? requestData.status : 'Pending', 
    };

    let response;
    if (editing) {
      response = await supabase.from('leave_requests').update(dataToSave).eq('id', requestData.id).select().single();
    } else {
      response = await supabase.from('leave_requests').insert(dataToSave).select().single();
    }
    
    const { data, error } = response;

    if (error) {
      console.error("Error saving leave request:", error);
      toast({ variant: "destructive", title: `Failed to ${editing ? 'update' : 'submit'} leave request`, description: error.message });
    } else {
      toast({ title: `Leave Request ${editing ? 'Updated' : 'Submitted'}`, description: `The leave request for ${data.leave_type} has been successfully ${editing ? 'updated' : 'submitted'}.` });
      fetchData();
      setIsModalOpen(false);
    }
  };

  const handleUpdateRequestStatus = async (id, newStatus) => {
    const { error } = await supabase.from('leave_requests').update({ status: newStatus }).eq('id', id);
    if (error) {
      toast({ variant: "destructive", title: "Status Update Failed", description: error.message });
    } else {
      toast({ title: "Status Updated", description: `Leave request status changed to ${newStatus}.` });
      fetchData();
    }
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500">Leave Management</h1>
          <p className="text-muted-foreground">Manage employee leave requests and balances.</p>
        </div>
        <Button onClick={() => handleOpenModal()} className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-500/90 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all">
          <CalendarPlus className="mr-2 h-5 w-5" /> Submit New Request
        </Button>
      </div>

      <Card className="shadow-xl border-0 bg-card/80 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <CalendarDays className="mr-3 h-7 w-7 text-primary" />
            <span>Leave Requests</span>
          </CardTitle>
          <CardDescription>
            View, manage, and approve/decline employee leave requests.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative flex-grow w-full sm:w-auto">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
                <Input
                  type="search"
                  placeholder="Search (employee, reason)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full bg-background/70 rounded-lg"
                />
            </div>
            <Select value={filterLeaveType} onValueChange={setFilterLeaveType}>
              <SelectTrigger className="w-full sm:w-[200px] bg-background/70">
                <SelectValue placeholder="Filter by Type" />
              </SelectTrigger>
              <SelectContent>
                {leaveTypesForFilter.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-[180px] bg-background/70">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {leaveStatusTypes.map(status => <SelectItem key={status} value={status}>{status}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <LeaveRequestTable 
            requests={leaveRequests}
            isLoading={isLoading}
            onUpdateRequestStatus={handleUpdateRequestStatus}
            onEditRequest={handleOpenModal}
            // onDeleteRequest={handleDeleteRequest} // Pass if implemented
          />
        </CardContent>
      </Card>

      <LeaveRequestForm
        isOpen={isModalOpen}
        setIsOpen={setIsModalOpen}
        onSubmit={handleFormSubmit}
        employees={employees}
        currentRequest={currentRequest}
        isEditing={isEditing}
      />

    </motion.div>
  );
};

export default LeaveManagementPage;