import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';
import { AlertTriangle, Search } from 'lucide-react';
import { motion } from 'framer-motion';
import AttendanceExceptionForm from '@/components/attendance/AttendanceExceptionForm';
import AttendanceExceptionTable from '@/components/attendance/AttendanceExceptionTable';

const initialExceptionState = {
  employee_id: '',
  date: new Date().toISOString().split('T')[0],
  exception_type: '',
  details: '',
  status: 'Pending',
};

// Simplified exception types
const attendanceExceptionTypes = [
  { value: "General Absence", label: "General Absence" },
  { value: "Sick Leave", label: "Sick Leave" },
  { value: "Other", label: "Other (Specify in details)"}
];

const attendanceExceptionStatusTypes = ["Pending", "Reviewed", "Resolved"];


const TimeAttendancePage = () => {
  const [employees, setEmployees] = useState([]);
  const [attendanceExceptions, setAttendanceExceptions] = useState([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isExceptionModalOpen, setIsExceptionModalOpen] = useState(false);
  const [currentException, setCurrentException] = useState(initialExceptionState);
  const [searchTermExceptions, setSearchTermExceptions] = useState('');
  const [filterExceptionType, setFilterExceptionType] = useState('all');
  const [filterExceptionStatus, setFilterExceptionStatus] = useState('all');

  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data: employeesData, error: employeesError } = await supabase.from('employees').select('id, name, employee_id');
      if (employeesError) throw employeesError;
      setEmployees(employeesData || []);

      const { data: exceptionsData, error: exceptionsError } = await supabase
        .from('attendance_exceptions')
        .select(`
          *,
          employees (name, employee_id)
        `)
        .order('date', { ascending: false });
      if (exceptionsError) throw exceptionsError;
      setAttendanceExceptions(exceptionsData || []);
      
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({ variant: "destructive", title: "Failed to load data", description: error.message });
    }
    setIsLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleExceptionInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentException(prev => ({ ...prev, [name]: value }));
  };
  
  const handleExceptionSelectChange = (name, value) => {
    setCurrentException(prev => ({ ...prev, [name]: value }));
  };

  const handleAddException = () => {
    setCurrentException(initialExceptionState);
    setIsExceptionModalOpen(true);
  };

  const handleSaveException = async (e) => {
    e.preventDefault();
    if (!currentException.employee_id || !currentException.date || !currentException.exception_type) {
      toast({ variant: "destructive", title: "Missing Fields", description: "Employee, Date, and Absence Type are required."});
      return;
    }

    const dataToSave = {
      employee_id: currentException.employee_id,
      date: currentException.date,
      exception_type: currentException.exception_type,
      details: currentException.details || null,
      status: currentException.status || 'Pending',
    };
    
    const { error } = await supabase.from('attendance_exceptions').insert(dataToSave);

    if (error) {
      console.error("Error saving absence:", error);
      toast({ variant: "destructive", title: "Failed to save absence", description: error.message });
    } else {
      toast({ title: "Absence Recorded", description: "The absence has been successfully recorded." });
      fetchData();
      setIsExceptionModalOpen(false);
    }
  };
  
  const filteredExceptions = attendanceExceptions.filter(ex => {
    const employeeName = ex.employees?.name?.toLowerCase() || '';
    const employeeId = ex.employees?.employee_id?.toLowerCase() || '';
    const searchLower = searchTermExceptions.toLowerCase();

    const matchesSearch = employeeName.includes(searchLower) || 
                          employeeId.includes(searchLower) ||
                          ex.exception_type.toLowerCase().includes(searchLower) ||
                          (ex.details && ex.details.toLowerCase().includes(searchLower));
    
    const matchesType = filterExceptionType === 'all' || ex.exception_type === filterExceptionType;
    const matchesStatus = filterExceptionStatus === 'all' || ex.status === filterExceptionStatus;

    return matchesSearch && matchesType && matchesStatus;
  });


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500">Absence Tracking</h1>
          <p className="text-muted-foreground">Record and manage employee absences and sick leave.</p>
        </div>
        <Button onClick={handleAddException} className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-500/90 hover:to-red-500/90 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all">
          <AlertTriangle className="mr-2 h-5 w-5" /> Record Absence
        </Button>
      </div>

      <Card className="shadow-xl border-0 bg-card/80 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="mr-3 h-7 w-7 text-destructive" />
            <span>Absence Records</span>
          </CardTitle>
          <CardDescription>
            Log and manage general absences and sick leave.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative flex-grow w-full sm:w-auto">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
                <Input
                  type="search"
                  placeholder="Search absences (name, ID, type, details)..."
                  value={searchTermExceptions}
                  onChange={(e) => setSearchTermExceptions(e.target.value)}
                  className="pl-10 w-full bg-background/70 rounded-lg"
                />
            </div>
            <Select value={filterExceptionType} onValueChange={setFilterExceptionType}>
              <SelectTrigger className="w-full sm:w-[200px] bg-background/70">
                <SelectValue placeholder="Filter by Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {attendanceExceptionTypes.map(type => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterExceptionStatus} onValueChange={setFilterExceptionStatus}>
              <SelectTrigger className="w-full sm:w-[180px] bg-background/70">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {attendanceExceptionStatusTypes.map(status => <SelectItem key={status} value={status}>{status}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <AttendanceExceptionTable 
            exceptions={filteredExceptions}
            isLoading={isLoading}
            searchTerm={searchTermExceptions}
            filterType={filterExceptionType}
            filterStatus={filterExceptionStatus}
          />
        </CardContent>
      </Card>

      <AttendanceExceptionForm
        isOpen={isExceptionModalOpen}
        setIsOpen={setIsExceptionModalOpen}
        currentException={currentException}
        handleInputChange={handleExceptionInputChange}
        handleSelectChange={handleExceptionSelectChange}
        handleSubmit={handleSaveException}
        employees={employees}
        exceptionTypes={attendanceExceptionTypes}
        exceptionStatusTypes={attendanceExceptionStatusTypes}
      />

    </motion.div>
  );
};

export default TimeAttendancePage;