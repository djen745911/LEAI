import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UserPlus, Search, Users } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import EmployeeFormModal from '@/components/employees/EmployeeFormModal';
import EmployeeTable from '@/components/employees/EmployeeTable';
import EmptyState from '@/components/employees/EmptyState';

const initialEmployeeState = { id: null, name: '', email: '', role: '', department: '', photo_url: null };

const EmployeeProfilesPage = () => {
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState(initialEmployeeState);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const fetchEmployees = useCallback(async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching employees:', error);
      toast({
        variant: "destructive",
        title: "Failed to load employees",
        description: error.message,
      });
      setEmployees([]);
    } else {
      setEmployees(data || []);
    }
    setIsLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  const handleFormSubmit = async (employeeData, editing) => {
    setIsLoading(true);
    let response;
    const dataToSubmit = {
      name: employeeData.name,
      email: employeeData.email,
      role: employeeData.role,
      department: employeeData.department,
      photo_url: employeeData.photo_url,
    };

    if (editing) {
      response = await supabase
        .from('employees')
        .update(dataToSubmit)
        .eq('id', employeeData.id)
        .select()
        .single();
    } else {
      response = await supabase
        .from('employees')
        .insert(dataToSubmit)
        .select()
        .single();
    }

    const { data, error } = response;

    if (error) {
      console.error('Error saving employee:', error);
      toast({
        variant: "destructive",
        title: `Failed to ${editing ? 'update' : 'add'} employee`,
        description: error.message,
      });
    } else {
      toast({
        title: `Employee ${editing ? 'Updated' : 'Added'}`,
        description: `${data.name}'s profile has been ${editing ? 'updated' : 'added'}.`,
      });
      fetchEmployees(); 
      setIsModalOpen(false);
      setCurrentEmployee(initialEmployeeState);
      setIsEditing(false);
    }
    setIsLoading(false);
  };
  
  const handleAddEmployee = () => {
    setCurrentEmployee(initialEmployeeState);
    setIsEditing(false);
    setIsModalOpen(true);
  };

  const handleEditEmployee = (employee) => {
    setCurrentEmployee(employee);
    setIsEditing(true);
    setIsModalOpen(true);
  };

  const handleDeleteEmployee = async (id) => {
    setIsLoading(true);
    const employeeToDelete = employees.find(emp => emp.id === id);
    const { error } = await supabase
      .from('employees')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting employee:', error);
      toast({
        variant: "destructive",
        title: "Failed to delete employee",
        description: error.message,
      });
    } else {
      toast({
        title: "Employee Deleted",
        description: `${employeeToDelete?.name || 'Employee'} has been removed.`,
      });
      fetchEmployees();
    }
    setIsLoading(false);
  };

  const filteredEmployees = employees.filter(employee =>
    employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (employee.department && employee.department.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.07,
        delayChildren: 0.1,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { type: 'spring', stiffness: 100 }
    }
  };

  return (
    <motion.div 
      className="space-y-8 p-1 sm:p-0"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <motion.div variants={itemVariants} className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-500 py-1">Employee Profiles</h1>
          <p className="text-muted-foreground">Manage your team's information efficiently.</p>
        </div>
        <Button 
          onClick={handleAddEmployee} 
          className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-500/90 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 ease-out"
          aria-label="Add New Employee"
        >
          <UserPlus className="mr-2 h-5 w-5" /> Add New Employee
        </Button>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl border-0 bg-card/80 backdrop-blur-lg rounded-xl overflow-hidden">
          <CardHeader className="border-b border-border/50 p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
              <CardTitle className="text-xl sm:text-2xl">Employee Directory</CardTitle>
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground pointer-events-none" />
                <Input
                  type="search"
                  aria-label="Search employees"
                  placeholder="Search employees..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full sm:w-64 md:w-72 bg-background/70 rounded-lg focus:ring-primary/50 focus:border-primary/50"
                />
              </div>
            </div>
            <CardDescription className="mt-1 text-xs sm:text-sm">
              {isLoading ? 'Loading employees...' : 
                (filteredEmployees.length > 0 ? `Showing ${filteredEmployees.length} of ${employees.length} employees.` : 
                  (searchTerm ? 'No employees found matching your search.' : 'No employees in the system yet.'))}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading && employees.length === 0 ? (
               <div className="text-center py-20 text-muted-foreground">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="mx-auto h-12 w-12 mb-4 text-primary"
                >
                  <Users /> 
                </motion.div>
                <p>Loading employees, please wait...</p>
              </div>
            ) : !isLoading && employees.length === 0 && !searchTerm ? (
              <EmptyState onAddEmployee={handleAddEmployee} itemVariants={itemVariants} />
            ) : (
              <EmployeeTable 
                employees={filteredEmployees} 
                onEdit={handleEditEmployee} 
                onDelete={handleDeleteEmployee} 
              />
            )}
            { !isLoading && filteredEmployees.length === 0 && searchTerm && employees.length > 0 && (
                <motion.div variants={itemVariants} className="text-center py-10 text-muted-foreground">
                    <Search className="mx-auto h-12 w-12 mb-4 text-primary/50" />
                    <h3 className="text-lg font-semibold mb-1 text-foreground">No Results Found</h3>
                    <p>Your search for "{searchTerm}" did not match any employees.</p>
                </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <EmployeeFormModal 
        isOpen={isModalOpen}
        setIsOpen={setIsModalOpen}
        currentEmployee={currentEmployee}
        isEditing={isEditing}
        onFormSubmit={handleFormSubmit}
      />
    </motion.div>
  );
};

export default EmployeeProfilesPage;