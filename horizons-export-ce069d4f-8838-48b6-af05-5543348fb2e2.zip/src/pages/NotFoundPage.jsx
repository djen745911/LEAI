import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

const NotFoundPage = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: "spring", stiffness: 120 }}
        className="text-center p-10 rounded-xl shadow-2xl bg-slate-800/50 backdrop-blur-md border border-slate-700"
      >
        <motion.div
          animate={{ rotate: [0, 10, -10, 0], y: [0, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <AlertTriangle className="mx-auto h-24 w-24 text-yellow-400 mb-8" />
        </motion.div>
        <h1 className="text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-orange-500">404</h1>
        <h2 className="text-3xl font-semibold mb-6 text-slate-200">Page Not Found</h2>
        <p className="text-slate-400 mb-8 max-w-md">
          Oops! The page you're looking for doesn't seem to exist. It might have been moved, deleted, or maybe you just mistyped the URL.
        </p>
        <Link to="/">
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-500/90 text-white shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
          >
            Go Back to Homepage
          </Button>
        </Link>
      </motion.div>
      <footer className="absolute bottom-8 text-sm text-slate-500">
        &copy; {new Date().getFullYear()} Employee Management System
      </footer>
    </div>
  );
};

export default NotFoundPage;